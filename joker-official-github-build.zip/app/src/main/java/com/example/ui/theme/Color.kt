package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Signature Joker Official Obsidian, Champagne Gold & Royal Emerald Palette
val EmeraldPrimaryLight = Color(0xFF0A6C6B)
val EmeraldPrimaryDark = Color(0xFF10B981)
val EmeraldDarkContainer = Color(0xFF064E3B)
val EmeraldLightContainer = Color(0xFFD1FAE5)
val OnEmeraldContainerLight = Color(0xFF022C22)
val OnEmeraldContainerDark = Color(0xFFA7F3D0)

val ChampagneGold = Color(0xFFE5B84B)
val ChampagneGoldDark = Color(0xFFB47B09)
val GoldContainerDark = Color(0xFF3F2E0A)
val GoldContainerLight = Color(0xFFFEF3C7)
val OnGoldContainerDark = Color(0xFFFDE68A)
val OnGoldContainerLight = Color(0xFF451A03)

val WhatsAppGreen = Color(0xFF16A34A)
val WhatsAppBright = Color(0xFF22C55E)
val WhatsAppContainer = Color(0xFFDCFCE7)
val OnWhatsAppContainer = Color(0xFF052E16)

val ObsidianBg = Color(0xFF0B0F17)
val ObsidianSurface = Color(0xFF131A26)
val ObsidianSurfaceVariant = Color(0xFF1C2536)
val ObsidianOutline = Color(0xFF2B384E)
val ObsidianText = Color(0xFFF8FAFC)
val ObsidianMuted = Color(0xFF94A3B8)

val IvoryBg = Color(0xFFF7F6F2)
val IvorySurface = Color(0xFFFFFFFF)
val IvorySurfaceVariant = Color(0xFFE9ECE8)
val IvoryOutline = Color(0xFFD0D7DE)
val IvoryText = Color(0xFF0F172A)
val IvoryMuted = Color(0xFF475569)
